
from django.shortcuts import render ,HttpResponseRedirect
from .models import user_data
import re  
    
def registration_view(request):
    # if request('No ! -------------------------',request.POST['age']) 
    if request.method == "POST":
        username = request.POST['username']
        first_name = request.POST['firstname']
        last_name = request.POST['lastname']
        email = request.POST['email']
        pass_WORD = request.POST['password']
        pass_WORD1 = request.POST['password']

        print(username,'-------------------------')
        if username != None:
            if first_name != None:
                if last_name != None  :
                    if email != None :
                        if pass_WORD != None:
                            pass_WORD = request.POST['password']
                            pass_WORD1 = request.POST['password1']
                            
                            # calculating the length
                            length_error = len(pass_WORD) < 8

                            # searching for digits
                            digit_error = re.search(r"\d", pass_WORD) is None

                            # searching for uppercase
                            uppercase_error = re.search(r"[A-Z]", pass_WORD) is None

                            # searching for lowercase
                            lowercase_error = re.search(r"[a-z]", pass_WORD) is None

                            # searching for symbols
                            symbol_error = re.search(r"[ !@#$%&'()*+,-./[\\\]^_`{|}~"+r'"]', pass_WORD) is None

                            # overall result
                            pass_WORD_ok = not ( length_error or digit_error or uppercase_error or lowercase_error or symbol_error )
                            print(pass_WORD_ok)
                            if pass_WORD_ok == True :
                                if pass_WORD  == pass_WORD1:
                                    print('yes ! ---------------------worked')
                                    pass_WORD = request.POST['password']
                                    user_data.objects.create(username = username, first_name = first_name , password = pass_WORD , last_name = last_name , email = email )

                                else:
                                    print('pass_WORD not match')
                            else:
                                print('not best pass_WORD')
                        else:
                            print('no pass_WORD')
                    else:
                        print('no email')
                else:
                    print('no last name')
            else :
                print('no first name')
        else:
            print('nousername')

    return render(request,'register.html')
